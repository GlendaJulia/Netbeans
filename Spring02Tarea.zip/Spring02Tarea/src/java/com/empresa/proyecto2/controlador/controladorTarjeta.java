package com.empresa.proyecto2.controlador;

import com.empresa.proyecto2.DTO.TarjetaDTO;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class controladorTarjeta {
    @RequestMapping(value="tarjeta")
    public ModelAndView mostrar(){
        ModelAndView mav = new ModelAndView("tarjeta");
        TarjetaDTO tarjetaForm = new TarjetaDTO();
        mav.addObject("tarje", tarjetaForm);
        return mav;
    }
    
    
    @RequestMapping(value="resultado", method = RequestMethod.POST)
    public ModelAndView resultado(@Valid @ModelAttribute("tarje") TarjetaDTO tarje,
            BindingResult rpta){
        if(rpta.hasErrors()){
            ModelAndView mav = new ModelAndView("tarjeta");
            return mav;
        }else{
            ModelAndView mav = new ModelAndView("resultado");
            return mav;
        }
    }
}






