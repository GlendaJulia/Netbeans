
package com.empresa.proyecto2.DTO;

import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

public class TarjetaDTO {
    @NotEmpty(message = "Este campo es obligatorio")
    private String apellido_p;
    
    @NotEmpty(message = "Este campo es obligatorio")
    private String apellido_m;
    
    @NotEmpty(message = "Este campo es obligatorio")
    private String nombre;
    
    private String[] dia = {"1", "2","3","4","5","6","7","8","9","10",
                            "11", "12","13","14","15","16","17","18","19","20",
                            "21", "22","23","24","25","26","27","28","29","30",
                            "31"};
    @NotEmpty(message = "Debe de seleccionar al menos una opcion")
    private String diaa;
    
    private String[] mes = {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
    @NotEmpty(message = "Debe de seleccionar al menos una opcion")
    private String mess;
    
    private String[] anio = {"2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989"};
    @NotEmpty(message = "Debe de seleccionar al menos una opcion")
    private String anioo;
    
    private String[] e_civil = {"Soltero", "Casado"};
    @NotEmpty(message = "Debe de seleccionar al menos una opcion")
    private String estado;
    
    private String[] sit_lab = {"Estudiante", "Egresado","Doctor","Ingeniero"};
    @NotEmpty(message = "Debe de seleccionar al menos una opcion")
    private String situacion;
    
    @NotEmpty(message = "Debe de seleccionar un valor")
    private String doc;
    
    @NotEmpty(message = "Debe de seleccionar un valor")
    private String sexo;
    
    @NotEmpty(message = "Es necesario aceptar los Terminos y Condiciones")
    private String term;
    
    @NotEmpty(message = "Este campo es obligatorio")
    @Pattern(regexp = ".*([0-9]\\.?\\d*)", message = "Solo se permiten datos numericos")
    @Length(min = 1, max = 8)
    private String nro_doc;
    
    @NotEmpty(message = "Este campo es obligatorio")
    @Pattern(regexp = ".*([0-9]\\.?\\d*)", message = "Solo se permiten datos numericos")
    @Length(min = 1, max = 11)
    private String ruc;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String[] getDia() {
        return dia;
    }

    public void setDia(String[] dia) {
        this.dia = dia;
    }

    public String getDiaa() {
        return diaa;
    }

    public void setDiaa(String diaa) {
        this.diaa = diaa;
    }

    public String[] getMes() {
        return mes;
    }

    public void setMes(String[] mes) {
        this.mes = mes;
    }

    public String getMess() {
        return mess;
    }

    public void setMess(String mess) {
        this.mess = mess;
    }

    public String[] getAnio() {
        return anio;
    }

    public void setAnio(String[] anio) {
        this.anio = anio;
    }

    public String getAnioo() {
        return anioo;
    }

    public void setAnioo(String anioo) {
        this.anioo = anioo;
    }

    public String[] getSit_lab() {
        return sit_lab;
    }

    public void setSit_lab(String[] sit_lab) {
        this.sit_lab = sit_lab;
    }

    public String getSituacion() {
        return situacion;
    }

    public void setSituacion(String situacion) {
        this.situacion = situacion;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNro_doc() {
        return nro_doc;
    }

    public void setNro_doc(String nro_doc) {
        this.nro_doc = nro_doc;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String[] getE_civil() {
        return e_civil;
    }

    public void setE_civil(String[] e_civil) {
        this.e_civil = e_civil;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getApellido_p() {
        return apellido_p;
    }

    public void setApellido_p(String apellido_p) {
        this.apellido_p = apellido_p;
    }

    public String getApellido_m() {
        return apellido_m;
    }

    public void setApellido_m(String apellido_m) {
        this.apellido_m = apellido_m;
    }
    
    public TarjetaDTO() {
    }
    
    
}
