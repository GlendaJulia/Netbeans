package tdd;

import java.math.BigDecimal;

public class Libro extends Producto{
    public Libro(BigDecimal precio){
        super(precio);
    }
}
