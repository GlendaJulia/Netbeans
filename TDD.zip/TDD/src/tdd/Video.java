package tdd;

import java.math.BigDecimal;

public class Video extends Producto{
    public Video(BigDecimal precio){
        super(precio);
    }
}
